@def title = "Electricity Markets Course" 
@def prepath = "em-course" 
@def description = """ A 5-day course on the economincs of electricity markets taught by Mar Reguant. """ 
@def author = "Mar Reguant"

<!--
Add here global latex commands to use throughout your pages.
-->
\newcommand{\R}{\mathbb R}
\newcommand{\scal}[1]{\langle #1 \rangle}
